This sample builds a simple pretty printer console
application using VRaniML.  This demonstrates
VRaniML's portability -- that is -- it does not
require any MS stuff.

Make sure you copy the .dll files from the VRaniML/runtime
directories to make this sample work.