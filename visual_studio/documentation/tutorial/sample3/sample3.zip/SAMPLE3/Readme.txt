This sample shows a simple MFC application using
VRaniML.

Make sure you copy the .dll files from the VRaniML/runtime
directories to make this sample work.