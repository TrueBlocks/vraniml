This sample shows a simple MS Windows Win32 application
using VRaniML.

Make sure you copy the .dll files from the VRaniML/runtime
directories to make this sample work.